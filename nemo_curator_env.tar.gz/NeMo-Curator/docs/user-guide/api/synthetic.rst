==================
Synthetic Data
==================

.. autoclass:: nemo_curator.synthetic.NemotronGenerator
    :members:

.. autoclass:: nemo_curator.synthetic.AsyncNemotronGenerator
    :members:

.. autoclass:: nemo_curator.synthetic.NemotronFormatter
    :members:

.. autoclass:: nemo_curator.synthetic.Mixtral8x7BFormatter
    :members:

.. autoclass:: nemo_curator.synthetic.NoFormat
    :members:

.. autoclass:: nemo_curator.synthetic.YamlConversionError
    :members:
