======================================
Datasets
======================================

-------------------
DocumentDataset
-------------------

.. autoclass:: nemo_curator.datasets.DocumentDataset
    :members:


-------------------------------
ImageTextPairDataset
-------------------------------

.. autoclass:: nemo_curator.datasets.ImageTextPairDataset
    :members: