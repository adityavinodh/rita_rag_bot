======================================
Image Curation
======================================

.. toctree::
   :maxdepth: 4
   :titlesonly:

   embedders.rst
   classifiers.rst