======================================
Embedders
======================================

------------------------------
Base Class
------------------------------

.. autoclass:: nemo_curator.image.embedders.ImageEmbedder
    :members:


------------------------------
Timm
------------------------------

.. autoclass:: nemo_curator.image.embedders.TimmImageEmbedder
    :members: