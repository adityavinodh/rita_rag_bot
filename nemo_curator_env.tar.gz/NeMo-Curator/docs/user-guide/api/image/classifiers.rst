======================================
Classifiers
======================================

------------------------------
Base Class
------------------------------

.. autoclass:: nemo_curator.image.classifiers.ImageClassifier
    :members:


------------------------------
Image Classifiers
------------------------------

.. autoclass:: nemo_curator.image.classifiers.AestheticClassifier
    :members:

.. autoclass:: nemo_curator.image.classifiers.NsfwClassifier
    :members: