======================================
Classifiers
======================================

.. autoclass:: nemo_curator.classifiers.DomainClassifier
    :members:

.. autoclass:: nemo_curator.classifiers.QualityClassifier
    :members:

.. autoclass:: nemo_curator.classifiers.FineWebEduClassifier
    :members:

.. autoclass:: nemo_curator.classifiers.AegisClassifier
    :members: