.. toctree::
   :maxdepth: 4
   :titlesonly:

   datasets.rst
   embedders.rst
   classifiers/index.rst