.. _data-curator-image-classifiers:

.. toctree::
   :maxdepth: 4
   :titlesonly:

   aesthetic.rst
   nsfw.rst