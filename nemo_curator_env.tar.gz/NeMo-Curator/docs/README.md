# Documentation
## User Guide
The [NeMo Framework User Guide](https://docs.nvidia.com/nemo-framework/user-guide/latest/datacuration/index.html) is the recommended way to view the documentation for each one of the NeMo Curator's modules.
